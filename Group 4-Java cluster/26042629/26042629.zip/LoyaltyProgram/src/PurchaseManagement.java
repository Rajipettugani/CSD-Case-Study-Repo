//package loyaltyprogram;

import java.sql.*;
import java.time.LocalDate;

public class PurchaseManagement {

    public static void addPurchase(int customerId, int rewardId, LocalDate purchaseDate, int pointsEarned) {
        String query = "INSERT INTO Purchase (customer_id, reward_id, purchase_date, points_earned) VALUES (?, ?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, customerId);
            stmt.setInt(2, rewardId);
            stmt.setDate(3, Date.valueOf(purchaseDate));
            stmt.setInt(4, pointsEarned);
            stmt.executeUpdate();
            
            updateCustomerPoints(customerId, pointsEarned);
            
            System.out.println("Purchase added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewPurchase(int purchaseId) {
        String query = "SELECT * FROM Purchase WHERE purchase_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, purchaseId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                System.out.println("Purchase ID: " + rs.getInt("purchase_id"));
                System.out.println("Customer ID: " + rs.getInt("customer_id"));
                System.out.println("Reward ID: " + rs.getInt("reward_id"));
                System.out.println("Purchase Date: " + rs.getDate("purchase_date"));
                System.out.println("Points Earned: " + rs.getInt("points_earned"));
            } else {
                System.out.println("Purchase not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updatePurchase(int purchaseId, int customerId, int rewardId, LocalDate purchaseDate, int pointsEarned) {
        String query = "UPDATE Purchase SET customer_id = ?, reward_id = ?, purchase_date = ?, points_earned = ? WHERE purchase_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, customerId);
            stmt.setInt(2, rewardId);
            stmt.setDate(3, Date.valueOf(purchaseDate));
            stmt.setInt(4, pointsEarned);
            stmt.setInt(5, purchaseId);
            int rowsUpdated = stmt.executeUpdate();
            
            if (rowsUpdated > 0) {
                System.out.println("Purchase updated successfully.");
            } else {
                System.out.println("Purchase not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deletePurchase(int purchaseId) {
        String query = "DELETE FROM Purchase WHERE purchase_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, purchaseId);
            int rowsDeleted = stmt.executeUpdate();
            
            if (rowsDeleted > 0) {
                System.out.println("Purchase deleted successfully.");
            } else {
                System.out.println("Purchase not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    private static void updateCustomerPoints(int customerId, int pointsEarned) {
        String query = "UPDATE Customer SET total_points = total_points + ? WHERE customer_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, pointsEarned);
            stmt.setInt(2, customerId);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
