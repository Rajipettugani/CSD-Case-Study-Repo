//package loyaltyprogram;

import java.util.Scanner;

public class Main {
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        while (true) {
            printMenu();
            int choice = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (choice) {
                case 1:
                    handleCustomerManagement();
                    break;
                case 2:
                    handleRewardManagement();
                    break;
                case 3:
                    handlePurchaseManagement();
                    break;
                case 4:
                    System.out.println("Exiting the program...");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private static void printMenu() {
        System.out.println("Customer Loyalty Program");
        System.out.println("1. Customer Management");
        System.out.println("2. Reward Management");
        System.out.println("3. Purchase Management");
        System.out.println("4. Exit");
        System.out.print("Enter your choice: ");
    }

    private static void handleCustomerManagement() {
        System.out.println("Customer Management");
        System.out.println("1. Add Customer");
        System.out.println("2. View Customer");
        System.out.println("3. Update Customer");
        System.out.println("4. Delete Customer");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter name: ");
                String name = scanner.nextLine();
                System.out.print("Enter email: ");
                String email = scanner.nextLine();
                System.out.print("Enter phone: ");
                String phone = scanner.nextLine();
                CustomerManagement.addCustomer(name, email, phone);
                break;
            case 2:
                System.out.print("Enter customer ID: ");
                int viewCustomerId = scanner.nextInt();
                CustomerManagement.viewCustomer(viewCustomerId);
                break;
            case 3:
                System.out.print("Enter customer ID: ");
                int updateCustomerId = scanner.nextInt();
                scanner.nextLine(); // consume newline
                System.out.print("Enter new name: ");
                String newName = scanner.nextLine();
                System.out.print("Enter new email: ");
                String newEmail = scanner.nextLine();
                System.out.print("Enter new phone: ");
                String newPhone = scanner.nextLine();
                CustomerManagement.updateCustomer(updateCustomerId, newName, newEmail, newPhone);
                break;
            case 4:
                System.out.print("Enter customer ID: ");
                int deleteCustomerId = scanner.nextInt();
                CustomerManagement.deleteCustomer(deleteCustomerId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void handleRewardManagement() {
        System.out.println("Reward Management");
        System.out.println("1. Add Reward");
        System.out.println("2. View Reward");
        System.out.println("3. Update Reward");
        System.out.println("4. Delete Reward");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter reward name: ");
                String rewardName = scanner.nextLine();
                System.out.print("Enter points required: ");
                int pointsRequired = scanner.nextInt();
                scanner.nextLine(); // consume newline
                System.out.print("Enter description: ");
                String description = scanner.nextLine();
                RewardManagement.addReward(rewardName, pointsRequired, description);
                break;
            case 2:
                System.out.print("Enter reward ID: ");
                int viewRewardId = scanner.nextInt();
                RewardManagement.viewReward(viewRewardId);
                break;
            case 3:
                System.out.print("Enter reward ID: ");
                int updateRewardId = scanner.nextInt();
                scanner.nextLine(); // consume newline
                System.out.print("Enter new reward name: ");
                String newRewardName = scanner.nextLine();
                System.out.print("Enter new points required: ");
                int newPointsRequired = scanner.nextInt();
                scanner.nextLine(); // consume newline
                System.out.print("Enter new description: ");
                String newDescription = scanner.nextLine();
                RewardManagement.updateReward(updateRewardId, newRewardName, newPointsRequired, newDescription);
                break;
            case 4:
                System.out.print("Enter reward ID: ");
                int deleteRewardId = scanner.nextInt();
                RewardManagement.deleteReward(deleteRewardId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }

    private static void handlePurchaseManagement() {
        System.out.println("Purchase Management");
        System.out.println("1. Add Purchase");
        System.out.println("2. View Purchase");
        System.out.println("3. Update Purchase");
        System.out.println("4. Delete Purchase");
        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();
        scanner.nextLine(); // consume newline

        switch (choice) {
            case 1:
                System.out.print("Enter customer ID: ");
                int customerId = scanner.nextInt();
                System.out.print("Enter reward ID: ");
                int rewardId = scanner.nextInt();
                scanner.nextLine(); // consume newline
                System.out.print("Enter purchase date (YYYY-MM-DD): ");
                String purchaseDate = scanner.nextLine();
                System.out.print("Enter points earned: ");
                int pointsEarned = scanner.nextInt();
                PurchaseManagement.addPurchase(customerId, rewardId, purchaseDate, pointsEarned);
                break;
            case 2:
                System.out.print("Enter purchase ID: ");
                int viewPurchaseId = scanner.nextInt();
                PurchaseManagement.viewPurchase(viewPurchaseId);
                break;
            case 3:
                System.out.print("Enter purchase ID: ");
                int updatePurchaseId = scanner.nextInt();
                scanner.nextLine(); // consume newline
                System.out.print("Enter new customer ID: ");
                int newCustomerId = scanner.nextInt();
                System.out.print("Enter new reward ID: ");
                int newRewardId = scanner.nextInt();
                scanner.nextLine(); // consume newline
                System.out.print("Enter new purchase date (YYYY-MM-DD): ");
                String newPurchaseDate = scanner.nextLine();
                System.out.print("Enter new points earned: ");
                int newPointsEarned = scanner.nextInt();
                PurchaseManagement.updatePurchase(updatePurchaseId, newCustomerId, newRewardId, newPurchaseDate, newPointsEarned);
                break;
            case 4:
                System.out.print("Enter purchase ID: ");
                int deletePurchaseId = scanner.nextInt();
                PurchaseManagement.deletePurchase(deletePurchaseId);
                break;
            default:
                System.out.println("Invalid choice. Please try again.");
        }
    }
}
