//package loyaltyprogram;

import java.sql.*;

public class RewardManagement {

    public static void addReward(String name, int pointsRequired, String description) {
        String query = "INSERT INTO Reward (name, points_required, description) VALUES (?, ?, ?)";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setString(1, name);
            stmt.setInt(2, pointsRequired);
            stmt.setString(3, description);
            stmt.executeUpdate();
            System.out.println("Reward added successfully.");
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void viewReward(int rewardId) {
        String query = "SELECT * FROM Reward WHERE reward_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, rewardId);
            ResultSet rs = stmt.executeQuery();
            
            if (rs.next()) {
                System.out.println("Reward ID: " + rs.getInt("reward_id"));
                System.out.println("Name: " + rs.getString("name"));
                System.out.println("Points Required: " + rs.getInt("points_required"));
                System.out.println("Description: " + rs.getString("description"));
            } else {
                System.out.println("Reward not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void updateReward(int rewardId, String name, int pointsRequired, String description) {
        String query = "UPDATE Reward SET name = ?, points_required = ?, description = ? WHERE reward_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setString(1, name);
            stmt.setInt(2, pointsRequired);
            stmt.setString(3, description);
            stmt.setInt(4, rewardId);
            int rowsUpdated = stmt.executeUpdate();
            
            if (rowsUpdated > 0) {
                System.out.println("Reward updated successfully.");
            } else {
                System.out.println("Reward not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static void deleteReward(int rewardId) {
        String query = "DELETE FROM Reward WHERE reward_id = ?";
        
        try (Connection conn = DatabaseConnection.getConnection();
             PreparedStatement stmt = conn.prepareStatement(query)) {
             
            stmt.setInt(1, rewardId);
            int rowsDeleted = stmt.executeUpdate();
            
            if (rowsDeleted > 0) {
                System.out.println("Reward deleted successfully.");
            } else {
                System.out.println("Reward not found.");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
